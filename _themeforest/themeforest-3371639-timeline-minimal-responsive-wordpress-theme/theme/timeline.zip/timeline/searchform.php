<form method="get" action="<?php echo esc_url(home_url('/')); ?>" role="search">
	<div class="row">
		<input type="text" class="field" name="s" id="s" /><input class="search" type="image" alt="Search" src="<?php echo get_template_directory_uri(); ?>/img/icons/search.png" />
	</div>
</form>