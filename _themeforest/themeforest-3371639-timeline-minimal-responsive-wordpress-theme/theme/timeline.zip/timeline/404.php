<?php
	header('HTTP/1.1 404 Not Found');
	header('Status: 404 Not Found');
?>

<?php
	// Header
	get_header();

	// View header.php for content

	// Footer
	get_footer();
?>